#!/usr/bin/env bash

java -cp classes/:lib/* com.gradescope.intlist.tests.RunTests
